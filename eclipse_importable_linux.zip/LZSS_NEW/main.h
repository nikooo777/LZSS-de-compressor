/*
 * main.h
 *
 *  Created on: Dec 11, 2014
 *      Author: spoofy
 */

#ifndef MAIN_H_
#define MAIN_H_
#include <stdio.h>
void write_to_file(FILE * f,unsigned char data[],long len);


#endif /* MAIN_H_ */
